namespace Secs4Net {
    public enum ConnectionState {
        Connecting,
        Connected,
        Selected,
        Retry
    }
}
